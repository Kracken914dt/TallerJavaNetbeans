package ejercicio5;

public class ejercicio5 {
      public static void main(String args[]) {
		int columna;
		int k;
		int matriz[][];
		matriz = new int[5][4];
		matriz[0][0] = 194;
		matriz[0][1] = 48;
		matriz[0][2] = 206;
		matriz[0][3] = 45;
		matriz[1][0] = 180;
		matriz[1][1] = 20;
		matriz[1][2] = 320;
		matriz[1][3] = 16;
		matriz[2][0] = 221;
		matriz[2][1] = 90;
		matriz[2][2] = 140;
		matriz[2][3] = 20;
		matriz[3][0] = 432;
		matriz[3][1] = 50;
		matriz[3][2] = 821;
		matriz[3][3] = 14;
		matriz[4][0] = 820;
		matriz[4][1] = 61;
		matriz[4][2] = 946;
		matriz[4][3] = 18;
		columna = 0;int suma = 0;
                
                double suma_1 = 0, suma_2 = 0, suma_3 = 0, suma_4 = 0; 
                double porcentaje1 = 0, porcentaje2 = 0, porcentaje3 = 0, porcentaje4 = 0;
		System.out.println("Columna   "+"Candidato A   "+"Candidato B   "+"Candidato C   "+"Candidato D   ");
                int pol = 0;
                int i = 0;
                double suma_total = 0;
		for (k=1;k<=5;k++) { 
                    
			columna = columna+1;
			System.out.println("   "+columna+"         "+matriz[k-1][0]+"           "+matriz[k-1][1]+"            "+matriz[k-1][2]+"             "+matriz[k-1][3]);
                   
                        
                        suma_1 += matriz[k - 1 ][0] ;
                        suma_2 += matriz[k - 1][1];
                        suma_3 += matriz[k - 1][2];
                        suma_4 += matriz[k - 1][3];
                        suma_total = suma_1 + suma_2 + suma_3 +suma_4;
                        porcentaje1 = suma_1;
                        porcentaje2 = suma_2;
                        porcentaje3 = suma_3;
                        porcentaje4 = suma_4;
 
		}
                System.out.println("\n" );

                    System.out.println(" La suma de los votos del candidato A es : "+suma_1);
                    System.out.println(" La suma de los votos del candidato B es : "+suma_2);
                    System.out.println(" La suma de los votos del candidato C es : "+suma_3);
                    System.out.println(" La suma de los votos del candidato D es : "+suma_4);
                    System.out.println("-------------------------------------------------------------------------");
                    System.out.println(" La suma total de los votos es: "+suma_total);
                    System.out.println("-------------------------------------------------------------------------");
                    System.out.println("El candidato con mas votaciones fue el C con : "+suma_3+" votos ");
                    
                      porcentaje1 = porcentaje1*100/suma_total;
                      porcentaje2 = porcentaje2*100/suma_total;
                      porcentaje3 = porcentaje3*100/suma_total;
                      porcentaje4 = porcentaje4*100/suma_total;
      
                    System.out.printf("%n El porcentaje de votaciones del candidato A es : %.2f", porcentaje1 );
                    System.out.printf("%n El porcentaje de votaciones del candidato B es : %.2f", porcentaje2 );
                    System.out.printf("%n El porcentaje de votaciones del candidato C es : %.2f", porcentaje3 );
                    System.out.printf("%n El porcentaje de votaciones del candidato D es : %.2f", porcentaje4 );
                    System.out.println("");
                    System.out.println("EL GANADOR DE LAS VOTACIONES HA SIDO EL CANDITADO C ");
                    System.out.println("CON UNA CANTIDAD DE VOTOS DE: "+suma_3);
                    System.out.printf("CON UN PORCENTAJE DEL: %.2f %n",porcentaje3);
                    System.out.println("-------------------------------------------------------------------------");
                
                    for (int z = 0; z < matriz.length; z++) {
                        int sumas = 0;
                        for (int m = 0; m < matriz[z].length; m++) {
                             System.out.printf("%d ", matriz[z][m]);
                             sumas += matriz[z][m];
                         }
                        System.out.printf("= %d\n", sumas);
                        
                    }   System.out.println("La comuna que más porcentaje de votación tuvo fue la 5");
           
	}

}
