package ejercicio2;

public class ejercicio2 {
    public static void main(String[] args) {
        int [] saldo_inicio_mes = {1200000, 3400000, 4000000, 1000000};
        int [] total_de_abonos_mes = {123000, 34000, 567000, 21000};
        int [] total_de_deducciones = {330000, 780000, 430000, 600000};
        int [] nuevo_saldo = new int[4];
        final int limite_credito = 1000000;
        int cliente = 0;
        for (int i = 0; i < 4; i++) {
            nuevo_saldo [i] = saldo_inicio_mes[i] + total_de_abonos_mes[i] - total_de_deducciones[i];
            cliente += 1;
            
            if (nuevo_saldo [i] >= limite_credito) {
                System.out.println("-------------------------------------");
                System.out.println("El cliente "+cliente+" tiene un nuevo balance de: "+nuevo_saldo[i]);
          
                System.out.println("Se excedió el límite de su crédito");
                System.out.println("-------------------------------------");
            } 
            else {
                System.out.println("-------------------------------------");
                System.out.println("El cliente "+cliente+" tiene un nuevo balance de: "+nuevo_saldo[i]);
                System.out.println("---------------------------------------");
            }
        }
       
            
    }
}
