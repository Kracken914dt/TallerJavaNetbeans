package ejercicio1;

import java.util.Scanner;

public class ejercicio1 {

    public static void main(String[] args) {
        int total = 0;
        int total2 = 0;
        int total3 = 0;
        int suma_uni = 0;
        int mayor3 = 0;
        int pos = 0;
        
       // introducion del tamaño del vector
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese el tamaño de su vector: ");
        int n = teclado.nextInt();
        int arreglo_A [] = new int [n];
        int arreglo_B [] = new int [n];
        int arreglo_C [] = new int [n];
        int calculototal [] = new int[n];
        
        // intoduccion de datos
        for (int i = 0; i < arreglo_B.length; i++) {
            System.out.print("Ingrese el valor de venta del producto "+(i+1)+" :");
            arreglo_B[i] = teclado.nextInt();
        }
         for (int i = 0; i < arreglo_C.length; i++) {
            System.out.print("Cantidad de unidades vendidas del producto "+(i+1)+" :");
            arreglo_C[i] = teclado.nextInt();
        }
         for (int i = 0; i < arreglo_A.length; i++) {
            System.out.print("Ingrese el codigo del producto "+(i+1)+" :");
            arreglo_A[i] = teclado.nextInt();
        }
         // multiplicacion de unidades por valor del producto
         for (int i = 0; i < calculototal.length; i++) {
            calculototal[i]=arreglo_B[i]*arreglo_C[i];
        }
         
        // suma del vector y de las unidades
        for (int i = 0; i < calculototal.length; i++) {
            total +=arreglo_C[i];
            total2 +=calculototal[i];
        }
        // el producto mas costoso vendido
        int mayor,menor;
        mayor = menor = (int) arreglo_B [0];
        for (int i = 0; i < arreglo_B.length; i++) {
            if(arreglo_B [i] > mayor) {
                mayor = (int) arreglo_B [i];   
            }
        }
        // el producto mas vendido en unidades
        int mayor2,menor3;
        
        mayor2 = menor3 = (int) arreglo_C [0];
        for (int f = 0; f < arreglo_C.length; f++){
            if(arreglo_C [f] > mayor2) {
                mayor2 = (int) arreglo_C [f];   
            }
        }
        
       int pose = -1;
        for (int k = 0; k < arreglo_C.length; k++) {
            suma_uni+= arreglo_C[k];
            if (mayor3 < arreglo_C[k]) {
                mayor3=arreglo_C[k];
                pose = k;
                
            }
        }
        System.out.println("--------------------------------------------------------------------------");
        System.out.println("El Total de productos vendidos en el dia es: "+total);
        System.out.println("El Total de ingresos por ventas del día es: "+total2);
        System.out.println("El producto " +(pose+1)+ " es el tiene más unidades vendidas que son: " +mayor2+" unidades");
        System.out.println("El producto mas costoso vendido es el que tiene un precio de : "+mayor);
        System.out.println("-------------------------------------------------------------------------");
    }}