package ejercicio4;

public class ejercicio4 {
    public static void main(String[] args) {
        int tarifaymedia = 0;
        final int Hora = 40;
        int sueldo = 0;
        int tarifa = 100000;
        int tarifa_extra = 0;
        int hora_extra = 0;
        String [] arreglo_E = new String[] {"juan","pedro","maria","marta"};
        int [] arreglo_H = {40,45,48,41};
        int [] arreglo_T = new int [4];
        for (int i = 0; i < 4; i++) {
            if (arreglo_H[i] <= Hora) {
                arreglo_T[i] = arreglo_H[i] * tarifa;
                System.out.println("El sueldo bruto del trabajador "+(arreglo_E[i])+" es:"+arreglo_T[i]);
        }
            else
                if (arreglo_H[i] > Hora) {
                    tarifaymedia = (int) ((int) tarifa + (0.50 * tarifa));
                    tarifa_extra = (int) (arreglo_T[i] + tarifaymedia);
                    hora_extra = arreglo_H[i] - 40; 
                    sueldo = (hora_extra * tarifa_extra + (40*tarifa));
                    System.out.println("El sueldo bruto del trabajador "+(arreglo_E[i])+" es:"+sueldo);   
                    
            }
        }
        
    }
}
