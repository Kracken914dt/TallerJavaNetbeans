package ejercicio3;

import java.util.Scanner;

public class ejercicio3 {
    public static void main(String[] args) {
        int total = 0;
        double incremento_porcent = 0;
        int [] arreglo = new int[7];
        // Categoria A
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print("Ingrese las ventas del dia "+(i+1)+" :");
            Scanner teclado = new Scanner(System.in);
            arreglo[i]=teclado.nextInt();
            total += arreglo[i];}
        if (total>3000 && total<5000) {
            double porcentaje = 0;
            porcentaje = (total * 5)/100 + 200;
            incremento_porcent = total + porcentaje; 
            System.out.println("---------------------------------------------------------------");
            System.out.println("Categoria A");
            System.out.println("Venta total de la semana es: "+ total);
            System.out.println("El total de comision de la semana es: "+porcentaje);
            System.out.println("El aumento del pago de la semana es: "+incremento_porcent);
            System.out.println("---------------------------------------------------------------");
        }
        else if (total >= 5000 && total <= 7000) {
            double porcentaje2 = 0;
            porcentaje2 = (total * 7)/100 + 200;
            incremento_porcent = total + porcentaje2; 
            System.out.println("---------------------------------------------------------------");
            System.out.println("Categoria A");
            System.out.println("Venta total de la semana es: "+ total);
            System.out.println("El total de comision de la semana es: "+porcentaje2);
            System.out.println("El aumento del pago de la semana es: "+incremento_porcent);
            System.out.println("---------------------------------------------------------------");
        }
        else if (total > 7000) {
            double porcentaje3 = 0;
            porcentaje3 = (total * 10)/100 + 200;
            incremento_porcent = total + porcentaje3;
            System.out.println("---------------------------------------------------------------");
            System.out.println("Categoria A");
            System.out.println("Venta total de la semana es: "+ total);
            System.out.println("El total de comision de la semana es: "+porcentaje3);
            System.out.println("El aumento del pago de la semana es: "+incremento_porcent);
            System.out.println("---------------------------------------------------------------");
                        
                    }
        
        // Categoria B
        int total2 = total;
        double incremento_porcent2 = 0;
        if (total2>5000 && total2<10000){
            double porcentaje4 = 0;
            porcentaje4 = (total2 * 7)/100 + 200;
            incremento_porcent2 = total2 + porcentaje4; 
            System.out.println("Categoria B");
            System.out.println("Venta total de la semana es: "+ total2);
            System.out.println("El total de comision de la semana es: "+porcentaje4);
            System.out.println("El aumento del pago de la semana es: "+incremento_porcent2);
        }
        else if (total2 >= 10000 && total2 <= 15000) {
            double porcentaje5 = 0;
            porcentaje5 = (total2 * 10)/100 + 200;
            incremento_porcent2 = total2 + porcentaje5; 
            System.out.println("Categoria B");
            System.out.println("Venta total de la semana es: "+ total2);
            System.out.println("El total de comision de la semana es: "+porcentaje5);
            System.out.println("El aumento del pago de la semana es: "+incremento_porcent2);
        }
        else if (total2 > 15000) {
            double porcentaje6 = 0;
            porcentaje6 = (total2 * 13) / 100 + 200;
            incremento_porcent2 = total2 + porcentaje6; 
            System.out.println("Categoria B");
            System.out.println("Venta total de la semana es: "+ total2);
            System.out.println("El total de comision de la semana es: "+porcentaje6);
            System.out.println("El aumento del pago de la semana es: "+incremento_porcent2);
        }
   
    }  
                }
            
        